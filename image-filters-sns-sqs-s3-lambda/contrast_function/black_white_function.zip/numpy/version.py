
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version: str = '1.20.3'
version: str = '1.20.3'
full_version: str = '1.20.3'
git_revision: str = '27b98cbe0dd9d2969e9c227e7a2070aa56f41d6d'
release: bool = True

if not release:
    version = full_version
